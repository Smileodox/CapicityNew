//
// Created by Paul Keck on 12.01.23.
//

#include "Leer.h"
#include "Holz.h"
#include "Kunststoff.h"
#include "Metall.h"

Leer::Leer() : Building("Leer", 0, 0, 0, {}) {

}