//
// Created by Paul Keck on 12.01.23.
//

#ifndef CAPICITYNEW_HOLZ_H
#define CAPICITYNEW_HOLZ_H


#include "Material.h"

class Holz : public Material{
public:
    Holz();

};


#endif //CAPICITYNEW_HOLZ_H
