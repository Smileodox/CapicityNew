//
// Created by Paul Keck on 12.01.23.
//

#include "Holz.h"

Holz::Holz() : Material("Holz", 10)
{

}
