//
// Created by Paul Keck on 12.01.23.
//

#ifndef CAPICITYNEW_LEER_H
#define CAPICITYNEW_LEER_H


#include "Building.h"

class Leer : public Building{
public:
    Leer();

};

#endif //CAPICITYNEW_LEER_H
