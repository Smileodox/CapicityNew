//
// Created by Paul Keck on 12.01.23.
//

#ifndef CAPICITYNEW_WINDKRAFTWERK_H
#define CAPICITYNEW_WINDKRAFTWERK_H


#include "Building.h"

class Windkraftwerk : public Building{
public:
    Windkraftwerk();

};


#endif //CAPICITYNEW_WINDKRAFTWERK_H
