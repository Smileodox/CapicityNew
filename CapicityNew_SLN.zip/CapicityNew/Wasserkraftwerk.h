//
// Created by Paul Keck on 12.01.23.
//

#ifndef CAPICITYNEW_WASSERKRAFTWERK_H
#define CAPICITYNEW_WASSERKRAFTWERK_H

#include "Material.h"
#include "Building.h"
#include "Holz.h"
#include "Metall.h"
#include "Kunststoff.h"

class Wasserkraftwerk : public Building {

public:
    Wasserkraftwerk();



};


#endif //CAPICITYNEW_WASSERKRAFTWERK_H
