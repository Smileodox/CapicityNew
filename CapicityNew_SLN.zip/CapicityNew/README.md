# CapicityNew
Ich habe meine CLion CMake Dateien bei meinem ersten Repo nicht gepusht, also neues Repo
