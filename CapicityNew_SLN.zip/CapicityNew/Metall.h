//
// Created by Paul Keck on 12.01.23.
//

#ifndef CAPICITYNEW_METALL_H
#define CAPICITYNEW_METALL_H


#include "Material.h"

class Metall : public Material{

public:
    Metall();

};


#endif //CAPICITYNEW_METALL_H
