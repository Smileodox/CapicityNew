//
// Created by Paul Keck on 12.01.23.
//

#include "Metall.h"

Metall::Metall() : Material("Metall", 30)
{

}