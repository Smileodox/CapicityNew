//
// Created by Paul Keck on 12.01.23.
//

#include "Material.h"

Material::Material(std::string name, int preis) : materialName(name), preis(preis)
{

}