//
// Created by Paul Keck on 12.01.23.
//
#include "CapicitySim.h"

int main(){
    CapicitySim sim;
    sim.start();
}