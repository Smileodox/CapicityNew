//
// Created by Paul Keck on 12.01.23.
//

#ifndef CAPICITYNEW_KUNSTSTOFF_H
#define CAPICITYNEW_KUNSTSTOFF_H


#include "Material.h"

class Kunststoff : public Material{

public:
    Kunststoff();

};


#endif //CAPICITYNEW_KUNSTSTOFF_H
