//
// Created by Paul Keck on 12.01.23.
//

#ifndef CAPICITYNEW_SOLARPANEL_H
#define CAPICITYNEW_SOLARPANEL_H


#include "Building.h"
#include "Holz.h"
#include "Kunststoff.h"
#include "Metall.h"

class Solarpanel : public Building{
public:
    Solarpanel();



};


#endif //CAPICITYNEW_SOLARPANEL_H
